package com.amd.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringseleApplicationTests {

	@Test
	void contextLoads() {
	}

}
